"""
flask_caching.backends.rediscache
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The redis caching backend.

:copyright: (c) 2018 by Peter Justin.
:copyright: (c) 2010 by Thadeus Burgess.
:license: BSD, see LICENSE for more details.
"""

from typing import Any

from cachelib import RedisCache as CachelibRedisCache
from flask import Flask

from flask_caching.backends.base import BaseCache


class RedisCache(BaseCache, CachelibRedisCache):
    """Uses the Redis key-value store as a cache backend.

    The first argument can be either a string denoting address of the Redis
    server or an object resembling an instance of a redis.Redis class.

    Note: Python Redis API already takes care of encoding unicode strings on
    the fly.

    :param host: address of the Redis server or an object which API is
        compatible with the official Python Redis client (``redis-py``).
    :param port: port number on which Redis server listens for connections.
    :param password: password authentication for the Redis server.
    :param db: db (zero-based numeric index) on Redis Server to connect.
    :param default_timeout: the default timeout that is used if no timeout is
                            specified on :meth:`~BaseCache.set`. A timeout of
                            0 indicates that the cache never expires.
    :param key_prefix: A prefix that should be added to all keys.
    :param ignore_delete_many_errors: If set to ``False`` the ``delete_many``
                                      method raises a ``RuntimeError`` in case
                                      a key couldn't be deleted.
                                      Defaults to ``False``.

    Any additional keyword arguments will be passed to ``redis.Redis``.
    """

    def __init__(
        self,
        host: Any = "localhost",
        port: int = 6379,
        password: str | None = None,
        db: int = 0,
        default_timeout: int = 300,
        key_prefix: str | None = None,
        ignore_delete_many_errors: bool = False,
        **kwargs: Any,
    ) -> None:
        CachelibRedisCache.__init__(
            self,
            host=host,
            port=port,
            password=password,
            db=db,
            default_timeout=default_timeout,
            key_prefix=key_prefix,
            ignore_delete_many_errors=ignore_delete_many_errors,
            **kwargs,
        )

    @classmethod
    def factory(
        cls,
        app: Flask,
        config: dict[str, Any],
        args: list[Any],
        kwargs: dict[str, Any],
    ) -> "RedisCache":
        try:
            from redis import from_url as redis_from_url
        except ImportError as e:
            raise RuntimeError("no redis module found") from e

        kwargs.update(
            dict(
                host=config.get("CACHE_REDIS_HOST", "localhost"),
                port=config.get("CACHE_REDIS_PORT", 6379),
                db=config.get("CACHE_REDIS_DB", 0),
            )
        )
        password = config.get("CACHE_REDIS_PASSWORD")
        if password:
            kwargs["password"] = password

        key_prefix = config.get("CACHE_KEY_PREFIX")
        if key_prefix:
            kwargs["key_prefix"] = key_prefix

        redis_url = config.get("CACHE_REDIS_URL")
        if redis_url:
            redis_kwargs = config.pop("CACHE_OPTIONS", None) or {}
            kwargs["host"] = redis_from_url(
                redis_url, db=kwargs.pop("db", None), **redis_kwargs
            )

        new_class = cls(*args, **kwargs)

        return new_class

    def unlink(self, *keys: str) -> Any:
        """when redis-py >= 3.0.0 and redis > 4, support this operation"""
        if not keys:
            return None
        prefix = self._get_prefix()
        if prefix:
            keys = tuple(prefix + key for key in keys)

        unlink = getattr(self._write_client, "unlink", None)
        if unlink is not None and callable(unlink):
            return self._write_client.unlink(*keys)
        return self._write_client.delete(*keys)


class RedisSentinelCache(RedisCache):
    """Uses the Redis key-value store as a cache backend.

    The first argument can be either a string denoting address of the Redis
    server or an object resembling an instance of a redis.Redis class.

    Note: Python Redis API already takes care of encoding unicode strings on
    the fly.


    :param sentinels: A list or a tuple of Redis sentinel addresses.
    :param master: The name of the master server in a sentinel configuration.
    :param password: password authentication for the Redis server.
    :param db: db (zero-based numeric index) on Redis Server to connect.
    :param default_timeout: the default timeout that is used if no timeout is
                            specified on :meth:`~BaseCache.set`. A timeout of
                            0 indicates that the cache never expires.
    :param key_prefix: A prefix that should be added to all keys.
    :param ignore_delete_many_errors: If set to ``False`` the ``delete_many``
                                      method raises a ``RuntimeError`` in case
                                      a key couldn't be deleted.
                                      Defaults to ``False``.

    Any additional keyword arguments will be passed to
    ``redis.sentinel.Sentinel``.
    """

    def __init__(
        self,
        sentinels: Any = None,
        master: str = "mymaster",
        password: str | None = None,
        db: int = 0,
        default_timeout: int = 300,
        key_prefix: str = "",
        ignore_delete_many_errors: bool = False,
        **kwargs: Any,
    ) -> None:
        try:
            import redis.sentinel
        except ImportError as e:
            raise RuntimeError("no redis module found") from e

        if kwargs.get("decode_responses", None):
            raise ValueError("decode_responses is not supported by RedisCache.")

        sentinels = sentinels or [("127.0.0.1", 26379)]
        sentinel_kwargs = {
            key[9:]: value
            for key, value in kwargs.items()
            if key.startswith("sentinel_")
        }
        kwargs = {
            key: value
            for key, value in kwargs.items()
            if not key.startswith("sentinel_")
        }

        sentinel = redis.sentinel.Sentinel(
            sentinels=sentinels,
            password=password,
            db=db,
            sentinel_kwargs=sentinel_kwargs,
            **kwargs,
        )

        write_client = sentinel.master_for(master)
        read_client = sentinel.slave_for(master)

        super().__init__(
            host=write_client,
            key_prefix=key_prefix,
            default_timeout=default_timeout,
            ignore_delete_many_errors=ignore_delete_many_errors,
        )

        self._read_client = read_client

    @classmethod
    def factory(
        cls,
        app: Flask,
        config: dict[str, Any],
        args: list[Any],
        kwargs: dict[str, Any],
    ) -> "RedisSentinelCache":
        kwargs.update(
            dict(
                sentinels=config.get("CACHE_REDIS_SENTINELS", [("127.0.0.1", 26379)]),
                master=config.get("CACHE_REDIS_SENTINEL_MASTER", "mymaster"),
                password=config.get("CACHE_REDIS_PASSWORD", None),
                sentinel_password=config.get("CACHE_REDIS_SENTINEL_PASSWORD", None),
                key_prefix=config.get("CACHE_KEY_PREFIX", None),
                db=config.get("CACHE_REDIS_DB", 0),
            )
        )

        return cls(*args, **kwargs)


class RedisClusterCache(RedisCache):
    """Uses the Redis key-value store as a cache backend.

    The first argument can be either a string denoting address of the Redis
    server or an object resembling an instance of a rediscluster.RedisCluster
    class.

    Note: Python Redis API already takes care of encoding unicode strings on
    the fly.


    :param cluster: The redis cluster nodes address separated by comma.
                    e.g. host1:port1,host2:port2,host3:port3 .
    :param password: password authentication for the Redis server.
    :param default_timeout: the default timeout that is used if no timeout is
                            specified on :meth:`~BaseCache.set`. A timeout of
                            0 indicates that the cache never expires.
    :param key_prefix: A prefix that should be added to all keys.
    :param ignore_delete_many_errors: If set to ``False`` the ``delete_many``
                                      method raises a ``RuntimeError`` in case
                                      a key couldn't be deleted.
                                      Defaults to ``False``.

    Any additional keyword arguments will be passed to
    ``rediscluster.RedisCluster``.
    """

    def __init__(
        self,
        cluster: Any = "",
        password: str = "",
        default_timeout: int = 300,
        key_prefix: str = "",
        ignore_delete_many_errors: bool = False,
        **kwargs: Any,
    ) -> None:
        if kwargs.get("decode_responses", None):
            raise ValueError("decode_responses is not supported by RedisCache.")

        try:
            from redis import RedisCluster
            from redis.cluster import ClusterNode
        except ImportError as e:
            raise RuntimeError("no redis.cluster module found") from e

        redis_url = kwargs.pop("redis_url", None)

        # Use URL-based connection if provided, otherwise use startup nodes.
        if redis_url:
            cluster = RedisCluster.from_url(redis_url, **kwargs)
        else:
            try:
                nodes = [(node.split(":")) for node in cluster.split(",")]
                startup_nodes = [
                    ClusterNode(node[0].strip(), int(node[1].strip())) for node in nodes
                ]
            except IndexError as e:
                raise ValueError(
                    "Please give the correct cluster argument "
                    "e.g. host1:port1,host2:port2,host3:port3"
                ) from e

            # Skips the check of cluster-require-full-coverage config,
            # useful for clusters without the CONFIG command (like aws)
            skip_full_coverage_check = kwargs.pop("skip_full_coverage_check", True)

            cluster = RedisCluster(
                startup_nodes=startup_nodes,
                password=password,
                skip_full_coverage_check=skip_full_coverage_check,
                **kwargs,
            )

        super().__init__(
            host=cluster,
            key_prefix=key_prefix,
            default_timeout=default_timeout,
            ignore_delete_many_errors=ignore_delete_many_errors,
        )

    @classmethod
    def factory(
        cls,
        app: Flask,
        config: dict[str, Any],
        args: list[Any],
        kwargs: dict[str, Any],
    ) -> "RedisClusterCache":
        kwargs.update(
            dict(
                cluster=config.get("CACHE_REDIS_CLUSTER", ""),
                password=config.get("CACHE_REDIS_PASSWORD", ""),
                default_timeout=config.get("CACHE_DEFAULT_TIMEOUT", 300),
                key_prefix=config.get("CACHE_KEY_PREFIX", ""),
                redis_url=config.get("CACHE_REDIS_URL", ""),
            )
        )
        return cls(*args, **kwargs)
