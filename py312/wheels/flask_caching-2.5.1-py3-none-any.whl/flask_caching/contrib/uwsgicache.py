"""
flask_caching.backends.uwsgicache
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The uWSGI caching backend.

:copyright: (c) 2018 by Peter Justin.
:copyright: (c) 2010 by Thadeus Burgess.
:license: BSD, see LICENSE for more details.
"""

from typing import Any

from cachelib import UWSGICache as CachelibUWSGICache
from flask import Flask

from flask_caching.backends.base import BaseCache


class UWSGICache(BaseCache, CachelibUWSGICache):
    """Implements the cache using uWSGI's caching framework.

    .. note::
        This class cannot be used when running under PyPy, because the uWSGI
        API implementation for PyPy is lacking the needed functionality.

    :param default_timeout: The default timeout in seconds.
    :param cache: The name of the caching instance to connect to, for
        example: mycache@localhost:3031, defaults to an empty string, which
        means uWSGI will use the first cache instance initialized.
        If the cache is in the same instance as the werkzeug app,
        you only have to provide the name of the cache.
    :param ignore_delete_many_errors: If set to ``False`` the ``delete_many``
                                      method raises a ``RuntimeError`` in case
                                      a key couldn't be deleted.
                                      Defaults to ``False``.
    """

    def __init__(
        self,
        default_timeout: int = 300,
        cache: str = "",
        ignore_delete_many_errors: bool = False,
    ) -> None:
        CachelibUWSGICache.__init__(
            self,
            cache=cache,
            default_timeout=default_timeout,
            ignore_delete_many_errors=ignore_delete_many_errors,
        )

        try:
            import uwsgi

            self._uwsgi = uwsgi
        except ImportError as e:
            raise RuntimeError(
                "uWSGI could not be imported, are you running under uWSGI?"
            ) from e

        if "cache2" not in uwsgi.opt:
            raise RuntimeError(
                "You must enable cache2 in uWSGI configuration: "
                "https://uwsgi-docs.readthedocs.io/en/latest/Caching.html"
            )

    @classmethod
    def factory(
        cls,
        app: Flask,
        config: dict[str, Any],
        args: list[Any],
        kwargs: dict[str, Any],
    ) -> "UWSGICache":
        # The name of the caching instance to connect to, for
        # example: mycache@localhost:3031, defaults to an empty string, which
        # means uWSGI will cache in the local instance. If the cache is in the
        # same instance as the werkzeug app, you only have to provide the name
        # of the cache.
        uwsgi_cache_name = config.get("CACHE_UWSGI_NAME", "")
        kwargs.update(dict(cache=uwsgi_cache_name))
        return cls(*args, **kwargs)
