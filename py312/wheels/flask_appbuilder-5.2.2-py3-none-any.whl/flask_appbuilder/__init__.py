__author__ = "Daniel Vaz Gaspar"
__version__ = "5.2.2"

from .actions import action  # noqa: F401
from .api import ModelRestApi  # noqa: F401
from .base import AppBuilder  # noqa: F401
from .baseviews import BaseView, expose  # noqa: F401
from .charts.views import DirectByChartView, GroupByChartView  # noqa: F401
from .models.group import aggregate_avg, aggregate_count, aggregate_sum  # noqa: F401
from .models.sqla import Model  # noqa: F401
from .security.decorators import has_access, permission_name  # noqa: F401
from .views import (  # noqa: F401
    CompactCRUDMixin,
    IndexView,
    MasterDetailView,
    ModelView,
    MultipleView,
    PublicFormView,
    SimpleFormView,
)  # noqa: F401
